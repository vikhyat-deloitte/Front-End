-- CreateTable
CREATE TABLE "Priority" (
    "pId" SERIAL NOT NULL,
    "PType" TEXT NOT NULL,

    CONSTRAINT "Priority_pkey" PRIMARY KEY ("pId")
);

-- CreateTable
CREATE TABLE "Type" (
    "tId" SERIAL NOT NULL,
    "tType" TEXT NOT NULL,

    CONSTRAINT "Type_pkey" PRIMARY KEY ("tId")
);

-- CreateTable
CREATE TABLE "Status" (
    "sId" SERIAL NOT NULL,
    "sType" TEXT NOT NULL,

    CONSTRAINT "Status_pkey" PRIMARY KEY ("sId")
);

-- CreateTable
CREATE TABLE "Team" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "Team_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "User" (
    "id" SERIAL NOT NULL,
    "first_name" TEXT NOT NULL,
    "last_name" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "teamID" INTEGER,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Team_name_key" ON "Team"("name");

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_teamID_fkey" FOREIGN KEY ("teamID") REFERENCES "Team"("id") ON DELETE SET NULL ON UPDATE CASCADE;
