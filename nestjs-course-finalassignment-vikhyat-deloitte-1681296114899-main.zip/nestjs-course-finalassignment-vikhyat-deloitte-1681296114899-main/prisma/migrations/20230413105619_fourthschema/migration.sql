/*
  Warnings:

  - You are about to drop the column `end_Date` on the `Issue` table. All the data in the column will be lost.
  - You are about to drop the column `pID` on the `Issue` table. All the data in the column will be lost.
  - You are about to drop the column `start_Date` on the `Issue` table. All the data in the column will be lost.
  - Added the required column `pId` to the `Issue` table without a default value. This is not possible if the table is not empty.
  - Made the column `description` on table `Issue` required. This step will fail if there are existing NULL values in that column.

*/
-- DropForeignKey
ALTER TABLE "Issue" DROP CONSTRAINT "Issue_pID_fkey";

-- AlterTable
ALTER TABLE "Issue" DROP COLUMN "end_Date",
DROP COLUMN "pID",
DROP COLUMN "start_Date",
ADD COLUMN     "end_date" TIMESTAMP(3),
ADD COLUMN     "pId" INTEGER NOT NULL,
ADD COLUMN     "start_date" TIMESTAMP(3),
ALTER COLUMN "description" SET NOT NULL,
ALTER COLUMN "reporterId" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_pId_fkey" FOREIGN KEY ("pId") REFERENCES "Priority"("priorityId") ON DELETE RESTRICT ON UPDATE CASCADE;
