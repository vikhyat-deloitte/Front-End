/*
  Warnings:

  - The primary key for the `Priority` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `pId` on the `Priority` table. All the data in the column will be lost.
  - Added the required column `projectID` to the `Team` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Priority" DROP CONSTRAINT "Priority_pkey",
DROP COLUMN "pId",
ADD COLUMN     "priorityId" SERIAL NOT NULL,
ADD CONSTRAINT "Priority_pkey" PRIMARY KEY ("priorityId");

-- AlterTable
ALTER TABLE "Team" ADD COLUMN     "projectID" INTEGER NOT NULL;

-- CreateTable
CREATE TABLE "Issue" (
    "issueID" SERIAL NOT NULL,
    "title" TEXT NOT NULL,
    "assigneeID" INTEGER NOT NULL,
    "reporterID" INTEGER NOT NULL,
    "pID" INTEGER NOT NULL,
    "statusID" INTEGER NOT NULL,
    "typeID" INTEGER NOT NULL,
    "epicId" INTEGER NOT NULL,
    "description" TEXT,
    "start_Date" TIMESTAMP(3),
    "end_Date" TIMESTAMP(3),

    CONSTRAINT "Issue_pkey" PRIMARY KEY ("issueID")
);

-- CreateTable
CREATE TABLE "EPIC" (
    "epicID" SERIAL NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "start_Date" TIMESTAMP(3),
    "end_Date" TIMESTAMP(3),
    "createdOn" TIMESTAMP(3),
    "updatedOn" TIMESTAMP(3),
    "projectID" INTEGER,
    "statusID" INTEGER NOT NULL,

    CONSTRAINT "EPIC_pkey" PRIMARY KEY ("epicID")
);

-- CreateTable
CREATE TABLE "Project" (
    "projectID" SERIAL NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "start_Date" TIMESTAMP(3),
    "end_Date" TIMESTAMP(3),
    "ownerID" INTEGER,

    CONSTRAINT "Project_pkey" PRIMARY KEY ("projectID")
);

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_assigneeID_fkey" FOREIGN KEY ("assigneeID") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_pID_fkey" FOREIGN KEY ("pID") REFERENCES "Priority"("priorityId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_statusID_fkey" FOREIGN KEY ("statusID") REFERENCES "Status"("sId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_typeID_fkey" FOREIGN KEY ("typeID") REFERENCES "Type"("tId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_epicId_fkey" FOREIGN KEY ("epicId") REFERENCES "EPIC"("epicID") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EPIC" ADD CONSTRAINT "EPIC_projectID_fkey" FOREIGN KEY ("projectID") REFERENCES "Project"("projectID") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EPIC" ADD CONSTRAINT "EPIC_statusID_fkey" FOREIGN KEY ("statusID") REFERENCES "Status"("sId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Project" ADD CONSTRAINT "Project_ownerID_fkey" FOREIGN KEY ("ownerID") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
