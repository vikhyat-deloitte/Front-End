/*
  Warnings:

  - The primary key for the `EPIC` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `createdOn` on the `EPIC` table. All the data in the column will be lost.
  - You are about to drop the column `end_Date` on the `EPIC` table. All the data in the column will be lost.
  - You are about to drop the column `epicID` on the `EPIC` table. All the data in the column will be lost.
  - You are about to drop the column `projectID` on the `EPIC` table. All the data in the column will be lost.
  - You are about to drop the column `start_Date` on the `EPIC` table. All the data in the column will be lost.
  - You are about to drop the column `statusID` on the `EPIC` table. All the data in the column will be lost.
  - You are about to drop the column `updatedOn` on the `EPIC` table. All the data in the column will be lost.
  - The primary key for the `Issue` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `assigneeID` on the `Issue` table. All the data in the column will be lost.
  - You are about to drop the column `issueID` on the `Issue` table. All the data in the column will be lost.
  - You are about to drop the column `reporterID` on the `Issue` table. All the data in the column will be lost.
  - You are about to drop the column `statusID` on the `Issue` table. All the data in the column will be lost.
  - You are about to drop the column `typeID` on the `Issue` table. All the data in the column will be lost.
  - The primary key for the `Project` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `end_Date` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `ownerID` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `projectID` on the `Project` table. All the data in the column will be lost.
  - You are about to drop the column `start_Date` on the `Project` table. All the data in the column will be lost.
  - The primary key for the `Team` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `Team` table. All the data in the column will be lost.
  - The primary key for the `User` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `User` table. All the data in the column will be lost.
  - You are about to drop the column `teamID` on the `User` table. All the data in the column will be lost.
  - Added the required column `statusId` to the `EPIC` table without a default value. This is not possible if the table is not empty.
  - Added the required column `assigneeId` to the `Issue` table without a default value. This is not possible if the table is not empty.
  - Added the required column `reporterId` to the `Issue` table without a default value. This is not possible if the table is not empty.
  - Added the required column `statusId` to the `Issue` table without a default value. This is not possible if the table is not empty.
  - Added the required column `typeId` to the `Issue` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "EPIC" DROP CONSTRAINT "EPIC_projectID_fkey";

-- DropForeignKey
ALTER TABLE "EPIC" DROP CONSTRAINT "EPIC_statusID_fkey";

-- DropForeignKey
ALTER TABLE "Issue" DROP CONSTRAINT "Issue_assigneeID_fkey";

-- DropForeignKey
ALTER TABLE "Issue" DROP CONSTRAINT "Issue_epicId_fkey";

-- DropForeignKey
ALTER TABLE "Issue" DROP CONSTRAINT "Issue_statusID_fkey";

-- DropForeignKey
ALTER TABLE "Issue" DROP CONSTRAINT "Issue_typeID_fkey";

-- DropForeignKey
ALTER TABLE "Project" DROP CONSTRAINT "Project_ownerID_fkey";

-- DropForeignKey
ALTER TABLE "Team" DROP CONSTRAINT "Team_projectId_fkey";

-- DropForeignKey
ALTER TABLE "User" DROP CONSTRAINT "User_teamID_fkey";

-- AlterTable
ALTER TABLE "EPIC" DROP CONSTRAINT "EPIC_pkey",
DROP COLUMN "createdOn",
DROP COLUMN "end_Date",
DROP COLUMN "epicID",
DROP COLUMN "projectID",
DROP COLUMN "start_Date",
DROP COLUMN "statusID",
DROP COLUMN "updatedOn",
ADD COLUMN     "created_on" TIMESTAMP(3),
ADD COLUMN     "end_date" TIMESTAMP(3),
ADD COLUMN     "epicId" SERIAL NOT NULL,
ADD COLUMN     "projectId" INTEGER,
ADD COLUMN     "start_date" TIMESTAMP(3),
ADD COLUMN     "statusId" INTEGER NOT NULL,
ADD COLUMN     "updated_on" TIMESTAMP(3),
ADD CONSTRAINT "EPIC_pkey" PRIMARY KEY ("epicId");

-- AlterTable
ALTER TABLE "Issue" DROP CONSTRAINT "Issue_pkey",
DROP COLUMN "assigneeID",
DROP COLUMN "issueID",
DROP COLUMN "reporterID",
DROP COLUMN "statusID",
DROP COLUMN "typeID",
ADD COLUMN     "assigneeId" INTEGER NOT NULL,
ADD COLUMN     "issueId" SERIAL NOT NULL,
ADD COLUMN     "reporterId" INTEGER NOT NULL,
ADD COLUMN     "statusId" INTEGER NOT NULL,
ADD COLUMN     "typeId" INTEGER NOT NULL,
ADD CONSTRAINT "Issue_pkey" PRIMARY KEY ("issueId");

-- AlterTable
ALTER TABLE "Project" DROP CONSTRAINT "Project_pkey",
DROP COLUMN "end_Date",
DROP COLUMN "ownerID",
DROP COLUMN "projectID",
DROP COLUMN "start_Date",
ADD COLUMN     "end_date" TIMESTAMP(3),
ADD COLUMN     "ownerId" INTEGER,
ADD COLUMN     "projectId" SERIAL NOT NULL,
ADD COLUMN     "start_date" TIMESTAMP(3),
ADD CONSTRAINT "Project_pkey" PRIMARY KEY ("projectId");

-- AlterTable
ALTER TABLE "Team" DROP CONSTRAINT "Team_pkey",
DROP COLUMN "id",
ADD COLUMN     "teamId" SERIAL NOT NULL,
ADD CONSTRAINT "Team_pkey" PRIMARY KEY ("teamId");

-- AlterTable
ALTER TABLE "User" DROP CONSTRAINT "User_pkey",
DROP COLUMN "id",
DROP COLUMN "teamID",
ADD COLUMN     "teamId" INTEGER,
ADD COLUMN     "uId" SERIAL NOT NULL,
ADD CONSTRAINT "User_pkey" PRIMARY KEY ("uId");

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_assigneeId_fkey" FOREIGN KEY ("assigneeId") REFERENCES "User"("uId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_statusId_fkey" FOREIGN KEY ("statusId") REFERENCES "Status"("sId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES "Type"("tId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Issue" ADD CONSTRAINT "Issue_epicId_fkey" FOREIGN KEY ("epicId") REFERENCES "EPIC"("epicId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EPIC" ADD CONSTRAINT "EPIC_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "Project"("projectId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EPIC" ADD CONSTRAINT "EPIC_statusId_fkey" FOREIGN KEY ("statusId") REFERENCES "Status"("sId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Project" ADD CONSTRAINT "Project_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES "User"("uId") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Team" ADD CONSTRAINT "Team_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "Project"("projectId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES "Team"("teamId") ON DELETE SET NULL ON UPDATE CASCADE;
