import { Controller, Get, Post, Body, Patch, Param, Delete, Put } from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User } from '@prisma/client';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post() //post req to create new user
  create(@Body() createUserDto: CreateUserDto) {
    return this.userService.createUser(createUserDto);
  }

  @Get() //get req to retrieve all users
  getUsers() :Promise<User[]>{
    return this.userService.get_All_Users();
  }

  @Get(':id') //get user by id
  getUser(@Param('id') id: string) : Promise<User>{
    return this.userService.get_User_by_ID(+id);
  }

  @Patch('resetPassword') //reset password for existing user
  update(@Body() updateUserDto: UpdateUserDto) : Promise<string|Object>{
    return this.userService.updatePwd(updateUserDto);
  }

  @Delete(':id') //delete user account
  remove(@Param('id') id: string):Promise<User|string> {
    return this.userService.remove(+id);
  }
}
