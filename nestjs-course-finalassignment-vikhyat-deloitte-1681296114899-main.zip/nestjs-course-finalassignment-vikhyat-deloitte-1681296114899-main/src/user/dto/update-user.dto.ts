import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateUserDto } from './create-user.dto';

export class UpdateUserDto {
    @ApiProperty()
    email: string
    @ApiProperty()
    oldPassword: string
    @ApiProperty()
    newPassword : string
    constructor(email,oldpwd,newpwd) {
        this.email=email
        this.oldPassword=oldpwd
        this.newPassword=newpwd
    }
}
