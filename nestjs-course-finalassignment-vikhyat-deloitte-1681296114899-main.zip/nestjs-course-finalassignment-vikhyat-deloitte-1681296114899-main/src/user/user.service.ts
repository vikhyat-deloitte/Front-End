import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { PrismaService } from '../prisma/prisma.service';
import { User } from '@prisma/client';
import * as bcrypt from "bcrypt"
import { HttpErrorByCode } from '@nestjs/common/utils/http-error-by-code.util';
@Injectable()
export class UserService {
  constructor(private readonly pService:PrismaService){}

  //creating new user
  async createUser(createUserDto: CreateUserDto) : Promise<User>{
    let checkEmail=true,checkTeam=true
    try{
      let emailResult=await this.pService.user.findFirst({
        where:{email:createUserDto.email}
      })
      if(emailResult) {
        checkEmail=false
        throw new Error('Email already exists')
      }
      let teamResult=await this.pService.team.findFirst({
        where: {teamId:createUserDto.teamId }
      })
      if(!teamResult){
        checkTeam=false
        throw new Error('Team ID does not exist')
      }
  
      const passwd=createUserDto.password
      const hash=await bcrypt.hash(passwd,5)
      createUserDto.password=hash
      return await this.pService.user.create({data : {...createUserDto}})
    }
    catch(err){
      if(!checkEmail) throw new HttpException(err.message,HttpStatus.CONFLICT)
      if(!checkTeam ) throw new HttpException(err.message,HttpStatus.NOT_FOUND)
      throw new HttpException(err,HttpStatus.BAD_REQUEST)
    }
  }

  //retriving all users present in DB
  async get_All_Users() : Promise<User[]>{
    try {
      return await this.pService.user.findMany()
    } catch (error) {
      throw new HttpException(error,HttpStatus.BAD_REQUEST)
    }
  }

  //retrieving user by particular ID. Returns empty[] if ID not present
  async get_User_by_ID(id: number) : Promise<User>{
    let userCheck=true
    try {
      let result= await this.pService.user.findFirst({
        where:{
          uId: id
        }
      })
      console.log(result)
      if(!result) {
        userCheck=false
        throw new Error('User does not exist')
      }
      return result
    } catch (error) {
      if(!userCheck) throw new HttpException(error.message,HttpStatus.NOT_FOUND)
      throw new HttpException(error,HttpStatus.BAD_REQUEST)
    }
    
  }

  //update the old password to new password
  async updatePwd(updateUserDto: UpdateUserDto): Promise<Object> {
    let userCheck=true,pwdCheck=true
    try {
      var user=await this.pService.user.findFirst({
        where:{
          email:updateUserDto.email
        }
      })
      if(!user){ //wrong email given
        userCheck=false
        throw new Error('User does not exist')
      }
      const result=await bcrypt.compare(updateUserDto.oldPassword,user.password) //comparing old and new passwords
      if (!result){
        pwdCheck=false
        throw new Error("Authentication failed") 
      }
      const newPass= await bcrypt.hash(updateUserDto.newPassword,5)
  
      return this.pService.user.update({
        where:{
          uId: user.uId
        },data:{
          password:newPass
        }
      })
    } 
    catch (error) {
      if(!userCheck) throw new HttpException(error.message,HttpStatus.NOT_FOUND)
      else if(!pwdCheck) throw new HttpException(error.message,HttpStatus.UNAUTHORIZED)
      else throw new HttpException(error,HttpStatus.BAD_REQUEST)
    }
  }


  //remove user from DB based on ID. If no record is found, then appropriate error message is shown
  async remove(id: number):Promise<User|string> {
    let userCheck=true
    try{
      let result=await this.pService.user.findFirst({
        where:{uId:id}
      })
      if(!result) {
        userCheck=false
        throw new Error('User does not exist')
      }
      return await this.pService.user.delete(
        {
          where:{
            uId: id
          }
        }
      )
    }
    catch(err){
      if(!userCheck) throw new HttpException(err.message,HttpStatus.NOT_FOUND)
      throw new HttpException(err,HttpStatus.BAD_REQUEST)
    }
  }
}
