export class User {
    
    first_name: string
    last_name: string
    role : string
    email: string
    password: string
    teamId? : number
    constructor(fname:string,lname:string,role:string,email:string,pwd:string,tId:number) {
        this.first_name=fname
        this.last_name=lname
        this.role=role
        this.email=email
        this.password=pwd
        this.teamId=tId
    }
}
