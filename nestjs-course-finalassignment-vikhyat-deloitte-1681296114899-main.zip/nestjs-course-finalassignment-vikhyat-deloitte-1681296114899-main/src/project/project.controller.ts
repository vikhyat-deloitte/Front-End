import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ProjectService } from './project.service';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';
import { Project } from '@prisma/client';
@Controller('project')
export class ProjectController {
  constructor(private readonly projectService: ProjectService) {}

  // post req to create new Project
  @Post()
  create(@Body() createProjectDto: CreateProjectDto) {
    try{
      return this.projectService.createProject(createProjectDto);
    }
    catch(e){
      return e
    }
  }


  //get req to retrieve all active projects
  @Get()
  getProject(): Promise<Project[]>{
    return this.projectService.getAll();
  }

  //get req to retrieve project based on ID 
  @Get(':id')
  getProjectByID(@Param('id') id: number) :Promise<Project|string>{
    return this.projectService.getProjectByID(+id);
  }

  //update req to change the details of the project
  @Patch(':id')
  update(@Param('id') id: number, @Body() updateProjectDto: UpdateProjectDto) : Promise<Project|string>{
    return this.projectService.updateProjectByID(+id, updateProjectDto);
  }

  //delete req for a particular project based on ID
  @Delete(':id')
  remove(@Param('id') id: number) {
    return this.projectService.removeProjectByID(+id);
  }
}
