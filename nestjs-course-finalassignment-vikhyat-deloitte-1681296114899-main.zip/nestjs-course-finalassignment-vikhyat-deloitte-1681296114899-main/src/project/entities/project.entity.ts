export class Project {
    title:string;
    description:string;
    start_date?: Date;
    end_date?:Date;
    ownerId?:number;
    constructor(title,description,start,end,owner){
        this.description=description
        this.title=title
        this.start_date=new Date(start)
        this.end_date=new Date(end)
        this.ownerId=owner
    }
}
