import { ApiProperty } from "@nestjs/swagger";

export class UpdateProjectDto  {
    @ApiProperty()
    title?:string;
    @ApiProperty()
    description?:string;
    @ApiProperty()
    start_date?: Date;
    @ApiProperty()
    @ApiProperty()
    end_date?:Date;
    @ApiProperty()
    ownerId?:number
    constructor(title:string='',description:string='',start:Date=new Date(),end:Date=new Date(),owner:number=-1){
        this.description=description
        this.title=title
        this.start_date=new Date(start)
        this.end_date=new Date(end)
        this.ownerId=owner
    }
}
