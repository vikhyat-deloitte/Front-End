import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { ProjectService } from './project.service';
import { ProjectController } from './project.controller';
import { PrismaModule } from 'src/prisma/prisma.module';
import { LoggerMiddleware } from 'src/middleware/logger.middleware.ts';

@Module({
  controllers: [ProjectController],
  providers: [ProjectService],
  imports:[PrismaModule]
})
export class ProjectModule {}