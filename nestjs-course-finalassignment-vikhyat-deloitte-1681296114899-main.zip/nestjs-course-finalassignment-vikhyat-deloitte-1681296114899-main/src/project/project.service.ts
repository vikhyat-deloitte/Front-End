import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateProjectDto } from './dto/create-project.dto';
import { UpdateProjectDto } from './dto/update-project.dto';
import { Project } from '@prisma/client';
import { PrismaService } from 'src/prisma/prisma.service';
@Injectable()
export class ProjectService {
  constructor(private readonly pService:PrismaService){}

  checkDate(exampleDto,fieldName){
    if(exampleDto[`${fieldName}`]){
        exampleDto[`${fieldName}`]=new Date(exampleDto[`${fieldName}`])
        return exampleDto[`${fieldName}`].toString()!='Invalid Date'
    }
    return true
  }
  //creating new Project
  async createProject(createProjectDto: CreateProjectDto) {
    try{
      var checkOwnerResult;
      var dateFlag:boolean=this.checkDate(createProjectDto,'start_date') && this.checkDate(createProjectDto,'end_date')
      if(!dateFlag) throw new Error('Date not formatted properly')
      if(createProjectDto.ownerId){
        checkOwnerResult= await this.pService.user.findMany({
          where : {
            uId:createProjectDto.ownerId
          }
        })
        if(!checkOwnerResult.length) throw new Error('User with given owner ID does not exist')
        return await this.pService.project.create({data:{...createProjectDto}})
      }
      
      // createProjectDto.start_date=new Date(createProjectDto.start_date)
      // createProjectDto.end_date=new Date(createProjectDto.end_date)
      // console.log(createProjectDto.start_date,typeof(createProjectDto.end_date))
      //if(createProjectDto.start_date=='Invalid Date'||createProjectDto.end_date=='Invalid Date') throw new Error('Enter Valid Date!')
      
    }
    catch(err){
      if(err.message=='Date not formatted properly') throw new HttpException(err.message,HttpStatus.BAD_REQUEST)
      else if(err.message=='User with given owner ID does not exist') throw new HttpException(err.message,HttpStatus.NOT_FOUND)
      else throw new HttpException("Something went wrong.",HttpStatus.INTERNAL_SERVER_ERROR)
    }
      
  }

  //retrieving all existing projects
  async getAll() : Promise <Project[]>{
    try{
      return this.pService.project.findMany()
    }
    catch(err){
      throw new HttpException(err,HttpStatus.INTERNAL_SERVER_ERROR)
    }
  }

  //retriving the project by ID. Return null if ID does not exist
  async getProjectByID(id: number) :Promise<Project>{
    if(!parseInt(''+id)) throw new Error('Enter Valid ID')
    try{
      let result=await this.pService.project.findMany({
        where:{
          projectId:{
            equals:id
          }
        }
      })
      if(!result.length) throw new Error('Project not found')
      return result[0]
    }
    catch(e){
      if(e.message=='Enter Valid ID') throw new HttpException(e.message,HttpStatus.BAD_REQUEST)
      throw new HttpException(e.message,HttpStatus.NOT_FOUND)
    }
    
  }

  //updates the details of project. if ID not found, error is thrown
  async updateProjectByID(id: number, updateProjectDto: UpdateProjectDto): Promise<Project| string>{
    try{
      var dateFlag:boolean=this.checkDate(updateProjectDto,'start_date') && this.checkDate(updateProjectDto,'end_date')
      if(!dateFlag) throw new Error('Date not formatted properly')
      
      console.log(updateProjectDto)
      
      let checkIfExists=await this.pService.project.findMany({
        where:{
          projectId:id
        }
      })
      if(!checkIfExists.length) throw new Error('Project ID not found')
      
      
      if(updateProjectDto.ownerId){
        let checkUserExists=await this.pService.user.findMany({
          where:{ uId:updateProjectDto.ownerId}
        })
        if(!checkUserExists.length) throw new Error('User not found')
      }
      return await this.pService.project.update({
        where:{
          projectId:id
        },data:updateProjectDto
      })
      
    } catch (e) {
      if(e.message && e.message=='Project ID not found'||e.message=='User not found')
        throw new HttpException(e.message,HttpStatus.NOT_FOUND)
      else
        throw new HttpException(e.message,HttpStatus.BAD_REQUEST)
    
    }
  }

  //removes the project which has a particular ID
  async removeProjectByID(id: number) {
    try{
      if(!parseInt(''+id)) throw new Error('Enter Valid ID')
      let epicToBeFound=await this.pService.project.findMany({
        where:{
          projectId:id
        }
      })
      if(!epicToBeFound.length) throw new Error('Project ID not found')
      return await this.pService.project.delete({
      where:{
        projectId:id
      }
    })
    }
    catch(err){
      if(err.message=='Enter Valid ID') throw new HttpException(err.message,HttpStatus.BAD_REQUEST)
      throw new HttpException(err.message,HttpStatus.NOT_FOUND)
    }
  }
}
