import { Injectable, NestMiddleware ,Logger} from '@nestjs/common';
import { Request, Response, NextFunction, response } from 'express';
@Injectable()
export class LoggerMiddleware implements NestMiddleware {
  private logger=new Logger('HTTP')
  use(req: Request, res: Response, next: NextFunction) : void{
    const {ip,method,originalUrl}=req
    const userAgent=req.get('user-agent')||''
    // fs.promises.writeFile('logger',JSON.stringify(data))
    res.on('finish',()=>{
      const {statusCode}=res
      var output=`${method} ${originalUrl} ${statusCode} ${userAgent} ${ip}`
      console.log(output)
      this.logger.log(output)
    })
    next();
  }
}
