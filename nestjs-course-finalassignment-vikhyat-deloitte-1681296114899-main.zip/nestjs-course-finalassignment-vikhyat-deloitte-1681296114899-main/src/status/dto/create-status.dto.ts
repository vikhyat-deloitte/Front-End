export class CreateStatusDto {}
