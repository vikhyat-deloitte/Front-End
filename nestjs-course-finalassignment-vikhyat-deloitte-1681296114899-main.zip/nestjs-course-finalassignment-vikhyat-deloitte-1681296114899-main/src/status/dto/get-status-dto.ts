import { EPIC, Issue } from "@prisma/client";

export class getStatusDTO{
    sId: number;
    sType: string;
    epics: EPIC[];
    issues: Issue[];
    constructor(sid,stype,epics,issues) {
        this.sId=sid
        this.sType=stype
        this.epics=epics
        this.issues=issues
    }
}