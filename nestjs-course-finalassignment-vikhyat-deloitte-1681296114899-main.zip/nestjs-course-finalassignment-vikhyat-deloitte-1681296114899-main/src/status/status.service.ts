import { Injectable } from '@nestjs/common';
import { CreateStatusDto } from './dto/create-status.dto';
import { UpdateStatusDto } from './dto/update-status.dto';
import { PrismaService } from '../prisma/prisma.service';
import { Status } from '@prisma/client';
@Injectable()
export class StatusService {
  constructor(private readonly pService:PrismaService){}
  //find all status present
  findAll():Promise<Status[]> {
    try{
      return this.pService.status.findMany();
    }
    catch (err){
      return err
    }
  }
}
