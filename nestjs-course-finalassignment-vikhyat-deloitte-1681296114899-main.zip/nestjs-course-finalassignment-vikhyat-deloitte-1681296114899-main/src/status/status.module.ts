import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { StatusService } from './status.service';
import { StatusController } from './status.controller';
import { PrismaModule } from 'src/prisma/prisma.module';
import { LoggerMiddleware } from 'src/middleware/logger.middleware.ts';
@Module({
  imports:[PrismaModule],
  controllers: [StatusController],
  providers: [StatusService]
})
export class StatusModule{}