import { Test, TestingModule } from '@nestjs/testing';
import { StatusController } from './status.controller';
import { StatusService } from './status.service';
import { PrismaService } from '../prisma/prisma.service';

describe('StatusController', () => {
  let service: StatusService;
  let controller: StatusController;
  const mockUserService={
    findAll:jest.fn(dto=>{
      return [{
        sId:1,
        sType:"In-progress"
      },
      {
        sId:2,
        sType:"Done"
      },
      {
        sId:3,
        sType:"To-do"
      },{
        sId:4,
        sType:"Blocked"
      }]
    })
  }
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [StatusService,PrismaService],
      controllers:[StatusController]
    }).overrideProvider(StatusService)
    .useValue(mockUserService)
    .compile();;

    service = module.get<StatusService>(StatusService);
    controller=module.get<StatusController>(StatusController)
  })

  it('service be defined', () => {
    expect(service).toBeDefined();
  });
  it('controller be defined', () => {
    expect(controller).toBeDefined();
  });
  it('should get all status', () => {
    expect(controller.findAllStatus()).toEqual([{
      sId:expect.any(Number),
      sType:"In-progress"
    },
    {
      sId:2,
      sType:"Done"
    },
    {
      sId:3,
      sType:"To-do"
    },{
      sId:4,
      sType:"Blocked"
    }]);
  });
  it('should get all status', () => {
    expect(controller.findAllStatus()).not.toEqual([{
      sId:expect.any(Number),
      sType:"In-progress"
    },
    {
      sId:3,
      sType:"Done"
    },
    {
      sId:2,
      sType:"To-do"
    },{
      sId:4,
      sType:"Blocked"
    }]);
  });
  
});
