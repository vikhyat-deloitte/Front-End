export class Issue {
    title : string;
    description: string;
    assigneeId?: number
    reporterId?: number
    typeId: number
    statusId: number
    priorityId: number 
    start_date?: Date
    end_date?: Date
    epicId: number
    constructor(title,desc,aId,rId,tId,sId,pId,sDate,eDate,eId){
        this.title=title
        this.description=desc
        this.assigneeId=aId
        this.epicId=eId
        this.end_date=eDate
        this.reporterId=rId
        this.statusId=sId
        this.start_date=sDate
        this.typeId=tId
        this.priorityId=pId
    }
}
