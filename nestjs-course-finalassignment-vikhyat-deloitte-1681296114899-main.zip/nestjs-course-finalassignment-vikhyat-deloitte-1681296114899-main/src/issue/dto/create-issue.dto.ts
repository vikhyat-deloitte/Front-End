import { ApiProperty } from "@nestjs/swagger";

export class CreateIssueDto {
    @ApiProperty()
    projectId:number
    @ApiProperty()
    title : string;
    @ApiProperty()
    description: string;
    @ApiProperty()
    assigneeId: number
    @ApiProperty()
    typeId: number
    @ApiProperty()
    statusId: number
    @ApiProperty()
    priorityId: number 
    @ApiProperty()
    start_date?: Date
    @ApiProperty()
    end_date?: Date
    @ApiProperty()
    epicId?: number
    constructor(title,desc,aId,tId,sId,pId,sDate,eDate,eId,projId){
        this.title=title
        this.description=desc
        this.assigneeId=aId
        this.epicId=eId
        this.end_date=eDate
        this.statusId=sId
        this.start_date=sDate
        this.typeId=tId
        this.priorityId=pId
        this.projectId=projId
    }
}
