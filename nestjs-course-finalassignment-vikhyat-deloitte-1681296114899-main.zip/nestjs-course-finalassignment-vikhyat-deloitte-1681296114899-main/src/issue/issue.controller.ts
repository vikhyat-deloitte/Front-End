import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { IssueService } from './issue.service';
import { CreateIssueDto } from './dto/create-issue.dto';
import { UpdateIssueDto } from './dto/update-issue.dto';
import { Issue } from '@prisma/client';

@Controller('issues')
export class IssueController {
  constructor(private readonly issueService: IssueService) {}

  //create new issue
  @Post('create')
  create(@Body() createIssueDto: CreateIssueDto) {
    return this.issueService.createIssue(createIssueDto);
  }
  
  //get data based on various filters
  @Post('filter')
  filter(@Body() filterIssueDto: UpdateIssueDto) {
    return this.issueService.filterIssues(filterIssueDto);
  }

  //get all issues present
  @Get('allIssue')
  findAllIssues() {
    return this.issueService.find_All_Issues();
  }

  //get issue by its ID
  @Get('issue/:id')
  async findOne(@Param('id') id: string):Promise<Issue|string> {
    return this.issueService.find_Issue_By_Id(+id);
  }

  //update the details of an issue based on its ID
  @Patch(':id')
  async update(@Param('id') id: string, @Body() updateIssueDto: UpdateIssueDto):Promise<Issue|string> {
    return this.issueService.update_Issue_By_Id(+id, updateIssueDto);
  }

  //delete an issue
  @Delete(':id')
  async remove(@Param('id') id: string):Promise<Issue|string> {
    return this.issueService.remove_Issue_By_Id(+id);
  }

  //get the issues pertaining to a particular project
  @Get('projectId/:id')
  async getByProject(@Param('id') id:number){
    return await this.issueService.findIssueByProjectId(+id)
  }
}
