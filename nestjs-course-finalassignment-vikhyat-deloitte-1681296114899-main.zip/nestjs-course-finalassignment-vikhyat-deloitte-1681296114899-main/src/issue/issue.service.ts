import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateIssueDto } from './dto/create-issue.dto';
import { UpdateIssueDto } from './dto/update-issue.dto';
import { PrismaService } from '../prisma/prisma.service';
import { FilterIssueDto } from './dto/filterIssueDto';
import {Prisma,Issue} from '@prisma/client';
@Injectable()
export class IssueService {
  constructor(private readonly pService:PrismaService){}

  //creating a new Issue
  createIssue(issue: CreateIssueDto) {
    let assigneeId: Prisma.UserCreateNestedOneWithoutIssueInput={connect:{uId: issue.assigneeId}}
    let typeid: Prisma.TypeCreateNestedOneWithoutIssuesInput={connect:{tId: issue.typeId}}
    let statusid: Prisma.StatusCreateNestedOneWithoutIssuesInput={connect:{sId: issue.statusId}}
    let prioid: Prisma.PriorityCreateNestedOneWithoutIssuesInput={connect:{priorityId: issue.priorityId}}
    let epicid: Prisma.EPICCreateNestedOneWithoutIssueInput={connect:{epicId: issue.epicId}}
    let projid: Prisma.ProjectCreateNestedOneWithoutIssueInput={connect:{projectId:issue.projectId}}
    let issuePrisma: Prisma.IssueCreateInput={title: issue.title, description: issue.description,assigneeUser:assigneeId, type:typeid, priority:prioid, status:statusid, epicContent:epicid, start_date: issue.start_date, end_date: issue.end_date, project: projid }
    if(issuePrisma.end_date) issuePrisma.end_date=new Date(issuePrisma.end_date)
    if(issuePrisma.start_date) issuePrisma.start_date=new Date(issuePrisma.start_date)
    return this.pService.issue.create({data:{...issuePrisma}})
  }

  //finding all issues present
  async find_All_Issues(): Promise<Issue[]> {
    return await this.pService.issue.findMany()
  }


  //finding a particular issue based on ID
  async find_Issue_By_Id(id: number): Promise<Issue|string> {
    if(parseInt(''+id)) 
    return await this.pService.issue.findFirst({
      where:{
        issueId:id
      }
    })
    return 'Enter Valid ID'
  }

  //updating an issue by its ID. Returns error if no ID found
  async update_Issue_By_Id(id:number,updateIssueDto:UpdateIssueDto):Promise<Issue|string>{
    if(updateIssueDto.start_date) updateIssueDto.start_date=new Date(updateIssueDto.start_date)
    if(updateIssueDto.end_date) updateIssueDto.end_date=new Date(updateIssueDto.end_date)
    if(parseInt(''+id)){
    try {
      return await this.pService.issue.update({
        where:{
          issueId:id
        },data:updateIssueDto
    })
      
    } catch (error) {
      return `Sorry, we encountered with the following error: ${error.meta.cause.toUpperCase()}\nPlease try again with a valid input`
    }
    }
    return 'Enter valid ID'
  }

  //remove issue based on its ID. Returns error as a string if no ID found
  async remove_Issue_By_Id(id: number) : Promise<Issue|string> {
    if(parseInt(''+id)){
    try{
      return await this.pService.issue.delete({
        where:{
          issueId:id
        }
      })
    }
    catch(e){
      return e.meta.cause
    }}
    return 'Enter Valid ID'
  }

  async filterIssues(filterIssueDto:FilterIssueDto){

    try {
      const{title,description, assigneeId,typeId,statusId,priorityId,start_date,end_date, epicId, projectId,reporterId}=filterIssueDto;
      
          let issues=await this.find_All_Issues()
      
       
      
          if(title){
      
            issues=(await issues).filter((issue)=>issue.title==title)
      
            //this.prisma.issue.findMany
      
          }
      
      
      
      
      
          if(assigneeId){
      
            issues=(await issues).filter((issue)=>issue.assigneeId==assigneeId)
      
          }
      
       
      
          if(typeId){
      
            issues=(await issues).filter((issue)=>issue.typeId==typeId)
      
          }
      
       
      
          if(statusId){
      
            issues=(await issues).filter((issue)=>issue.statusId==statusId)
      
          }
      
       
      
          if(priorityId){
      
            issues=(await issues).filter((issue)=>issue.pId==priorityId)
      
          }
      
       
      
          if(epicId){
      
            issues=(await issues).filter((issue)=>issue.epicId==epicId)
      
          }
      
       
      
          if(reporterId){
      
            issues=(await issues).filter((issue)=>issue.reporterId==reporterId)
      
          }
      
      
      
      
      
          if(projectId){
      
            issues=(await issues).filter((issue)=>issue.projectId==projectId)
      
          }
      
       
      
          if(issues.length==0){
      
            throw new Error("No issues to display.")
      
          }
      
       
      
          return await issues
      
    } catch (error) {
      throw new HttpException(error.message,HttpStatus.NOT_FOUND)
    }
          
        
  }

  async findIssueByProjectId(id:number):Promise<Issue[]|string>{
    if(!parseInt(''+id)) return 'Enter Valid ID'
    try{
      return await this.pService.issue.findMany({
        where:{
          projectId:id
        }
      })
    }
    catch(e){
      return e.meta.cause
    }
  }
}
