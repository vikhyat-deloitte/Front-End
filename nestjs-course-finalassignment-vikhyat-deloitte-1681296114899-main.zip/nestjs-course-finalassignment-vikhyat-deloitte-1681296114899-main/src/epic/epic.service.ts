import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateEpicDto } from './dto/create-epic.dto';
import { UpdateEpicDto } from './dto/update-epic.dto';
import { PrismaService } from '../prisma/prisma.service';
import { EPIC } from '@prisma/client';
@Injectable()
export class EpicService {
  constructor(private readonly pService:PrismaService){}

  
  checkDate(exampleDto,fieldName){
    if(exampleDto[`${fieldName}`]){
        exampleDto[`${fieldName}`]=new Date(exampleDto[`${fieldName}`])
        return exampleDto[`${fieldName}`].toString()!='Invalid Date'
    }
    return true
  }
  //create new EPIC
  async create_EPIC(createEpicDto: CreateEpicDto) : Promise<EPIC>{
    try{
      var dateFlag:boolean=this.checkDate(createEpicDto,'start_date') && this.checkDate(createEpicDto,'end_date')&& this.checkDate(createEpicDto,'created_on')&&this.checkDate(createEpicDto,'updated_on')
      if(!dateFlag) throw new Error('Date not formatted properly')
      const flag= (await this.pService.project.findMany({where:{projectId:createEpicDto.projectId}})).length
      if(flag) return await this.pService.ePIC.create({data:{...createEpicDto}})
      else{
        throw new Error('Project ID not found')
      }
    }
    catch(e){
      if(e.message && e.message=='Project ID not found')
        throw new HttpException(e.message,HttpStatus.NOT_FOUND)
      else
        throw new HttpException(e.message,HttpStatus.BAD_GATEWAY)
    }
  }

  //retrieve all EPICs
  async find_All_EPICS(): Promise<EPIC[]> {
    try{

      return await this.pService.ePIC.findMany()
    }
    catch(e){
      throw new HttpException(e,HttpStatus.NO_CONTENT)
    }
  }

  //retrieve EPIC by an ID
  async get_EPIC_By_ID(id: number):Promise<EPIC|string> {
    if(!parseInt(''+id)) throw new HttpException('Enter Valid ID',HttpStatus.BAD_REQUEST)
    try{
      let result= await this.pService.ePIC.findMany({
        where:{
          epicId:id
        }
      })
      if(result.length==0) throw new Error('No EPIC Found')
      return result[0]
    }
    catch(err){
      throw new HttpException(err.message,HttpStatus.NOT_FOUND)
    }
  }

  //get details of all EPICs associated with a project
  async get_EPIC_by_Project(projectIdentifier:number): Promise<EPIC[]>{
    try{
      if(!parseInt(''+projectIdentifier)) throw new Error('Enter Valid ID')
      let pidResult=await this.pService.project.findMany({
        where:
        {
          projectId:projectIdentifier
        }
      })
      if(pidResult.length==0) throw new Error('Invalid Project ID')
      return await this.pService.ePIC.findMany({
        where:
        {
          projectId:projectIdentifier
        }
      })
    }
    catch(err){
      throw new HttpException(err.message,HttpStatus.NOT_FOUND)
    }
  }

  //update details of an EPIC by ID
  async update_EPIC_By_ID(id: number, updateEpicDto: UpdateEpicDto) : Promise<EPIC | string> {
    let flag=true,flagProjectId=true
    try {
      if(!parseInt(''+id)) throw new Error('Enter Valid ID')
      if(updateEpicDto.start_date) flag=flag&&this.checkDate(updateEpicDto,'start_date')
      if(updateEpicDto.end_date)  flag=flag&&this.checkDate(updateEpicDto,'end_date')
      if(updateEpicDto.created_on) flag=flag&&this.checkDate(updateEpicDto,'created_on')
      if(updateEpicDto.updated_on)  flag=flag&&this.checkDate(updateEpicDto,'updated_on')
      if(!flag) throw new Error('Date not formatted properly')
      if(updateEpicDto.projectId!=undefined){
        let preCheckProjectId=await this.pService.project.findMany({
          where:{projectId:updateEpicDto.projectId}
        })
        console.log("UH huh",preCheckProjectId.length)
        if(!preCheckProjectId.length) {
          flagProjectId=false
          throw new Error('Project ID not found')
        }
      }
      let result=await this.pService.ePIC.update({
        where:{
          epicId:id
        },data:updateEpicDto
      })
      return result
    } 
    catch (error) {
      if(!flag) throw new HttpException(error.message,HttpStatus.BAD_REQUEST)
      else if(!flagProjectId) throw new HttpException(error.message,HttpStatus.NOT_FOUND)
      else throw new HttpException(` ${error.meta.cause.toUpperCase()}Please try again with a valid input`,HttpStatus.NOT_FOUND)
    }
  }

  //delete a particular EPIC
  async remove_EPIC_By_ID(id: number) : Promise<EPIC|string>{
    try{
      if(!parseInt(''+id)) throw new Error('Enter Valid ID')
      let epicToBeFound=await this.pService.ePIC.findMany({
        where:{
          epicId:id
        }
      })
      if(!epicToBeFound.length) throw new Error('No EPIC Found')
      return await this.pService.ePIC.delete({
      where:{
        epicId:id
      }
    })
    }
    catch(err){
      if(err.message=='Enter Valid ID') throw new HttpException(err.message,HttpStatus.BAD_REQUEST)
      throw new HttpException(err.message,HttpStatus.NOT_FOUND)
    }
  }
}
