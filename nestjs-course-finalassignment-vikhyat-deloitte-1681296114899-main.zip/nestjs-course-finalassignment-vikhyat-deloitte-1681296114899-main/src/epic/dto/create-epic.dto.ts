import { ApiProperty } from "@nestjs/swagger";

export class CreateEpicDto {
    @ApiProperty()
    title: string;
    @ApiProperty()
    statusId: number
    @ApiProperty()
    description?: string
    @ApiProperty()
    start_date?: Date
    @ApiProperty()
    end_date?: Date
    @ApiProperty()
    created_on?: Date
    @ApiProperty()
    updated_on?: Date
    @ApiProperty()
    projectId: number
    constructor(title: string,
        statusId: number,
        description: string,
        start_date: Date,
        end_date: Date,
        created_on: Date,
        updated_on: Date,
        projectId: number,
        statusID:number){
            this.title=title
            this.statusId=statusId
            this.description=description
            this.start_date=start_date
            this.end_date=end_date
            this.created_on=created_on
            this.updated_on=updated_on
            this.projectId=projectId
            this.statusId=statusID
        }
  }