import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { EpicService } from './epic.service';
import { EpicController } from './epic.controller';
import { PrismaModule } from 'src/prisma/prisma.module';
import { LoggerMiddleware } from 'src/middleware/logger.middleware.ts';

@Module({
  imports:[PrismaModule],
  controllers: [EpicController],
  providers: [EpicService]
})
export class EpicModule {}