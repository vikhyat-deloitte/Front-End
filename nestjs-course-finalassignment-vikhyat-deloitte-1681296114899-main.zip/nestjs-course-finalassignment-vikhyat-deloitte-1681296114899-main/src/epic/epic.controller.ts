import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { EpicService } from './epic.service';
import { CreateEpicDto } from './dto/create-epic.dto';
import { UpdateEpicDto } from './dto/update-epic.dto';
import { EPIC } from '@prisma/client';
import { type } from 'os';

@Controller('epic')
export class EpicController {
  constructor(private readonly epicService: EpicService) {}

  //create new EPIC
  @Post()
  create(@Body() createEpicDto: CreateEpicDto) {
    return this.epicService.create_EPIC(createEpicDto);
  }

  //get all epic
  @Get()
  getEPICS(): Promise<EPIC[]> {
    return this.epicService.find_All_EPICS();
  }
  
  //get particular epic by ID
  @Get(':id')
  async getEpicByID(@Param('id') id: number):Promise<EPIC|string> {
    return this.epicService.get_EPIC_By_ID(+id);
  }

  //get all EPICs associated with a project
  @Get('byProjectId/:id')
  async getEpicByProject(@Param('id') pid: number) : Promise<EPIC[]|string>{
      return await this.epicService.get_EPIC_by_Project(+pid);
  }

  //update details of EPIC
  @Patch(':id')
  async updateEpicByID(@Param('id') id: number, @Body() updateEpicDto: UpdateEpicDto) : Promise<EPIC | string> {
      return await this.epicService.update_EPIC_By_ID(+id, updateEpicDto);
  }

  //delete an EPIC
  @Delete(':id')
  async removeEpicByID(@Param('id') id: number) :Promise<EPIC|string> {
      return this.epicService.remove_EPIC_By_ID(+id);
  }
}
