export class Epic {
    title: string;
    statusId: number
    description?: string
    start_date?: Date
    end_date?: Date
    created_on?: Date
    updated_on?: Date
    projectId: number
    statusID: number
    constructor(title: string,
        statusId: number,
        description: string,
        start_date: Date,
        end_date: Date,
        created_on: Date,
        updated_on: Date,
        projectId: number,
        statusID:number){
            this.title=title
            this.statusId=statusId
            this.description=description
            this.start_date=start_date
            this.end_date=end_date
            this.created_on=created_on
            this.updated_on=updated_on
            this.projectId=projectId
            this.statusID=statusID
        }
  }