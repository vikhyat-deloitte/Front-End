import { MiddlewareConsumer, Module, NestModule } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";

// import { UserModule } from "./user/user.module";

// import { TeamModule } from "./team/team.module";

import { ConfigModule } from "@nestjs/config";
import { StatusModule } from './status/status.module';
import { PriorityModule } from './priority/priority.module';
import { TypeModule } from './type/type.module';
import { ProjectModule } from './project/project.module';
import { EpicModule } from './epic/epic.module';
import { TeamModule } from './team/team.module';
import { UserModule } from './user/user.module';
import { IssueModule } from './issue/issue.module';
import { LoggerMiddleware } from "./middleware/logger.middleware.ts";
import { AuthModule } from './auth/auth.module';
import { AuthController } from "./auth/auth.controller";

@Module({
  imports: [
    ConfigModule.forRoot({isGlobal: true}),
    StatusModule,
    PriorityModule,
    TypeModule,
    ProjectModule,
    EpicModule,
    TeamModule,
    UserModule,
    IssueModule,
    AuthModule,
  ],

  controllers: [AppController,AuthController],
  providers: [AppService],
})
export class AppModule implements NestModule{
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LoggerMiddleware).forRoutes('*')
  }
}