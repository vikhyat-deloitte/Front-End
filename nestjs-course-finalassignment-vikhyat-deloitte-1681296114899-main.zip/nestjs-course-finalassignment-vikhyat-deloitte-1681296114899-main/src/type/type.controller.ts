import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { TypeService } from './type.service';
import { CreateTypeDto } from './dto/create-type.dto';
import { UpdateTypeDto } from './dto/update-type.dto';
import { Type } from '@prisma/client';
@Controller('type')
export class TypeController {
  constructor(private readonly typeService: TypeService) {}


  @Get() //get req for all types of issues
  findAllTypesOfIssues(): Promise<Type[]> {
    return this.typeService.findAll();
  }
}
