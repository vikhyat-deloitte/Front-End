export class Type {}
