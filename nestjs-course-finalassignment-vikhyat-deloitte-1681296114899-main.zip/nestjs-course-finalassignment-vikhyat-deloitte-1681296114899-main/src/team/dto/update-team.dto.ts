import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateTeamDto } from './create-team.dto';
import { User } from '@prisma/client';

export class AddUserToTeamDto{
    
    @ApiProperty()
    teamId: number
    @ApiProperty()
    users: User[]
    constructor(tId:number,newUsers:User[]){
        this.teamId=tId
        this.users=newUsers
}

}