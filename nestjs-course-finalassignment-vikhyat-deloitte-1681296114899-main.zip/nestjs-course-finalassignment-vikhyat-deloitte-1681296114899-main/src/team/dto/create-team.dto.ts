import { ApiProperty } from "@nestjs/swagger"

export class CreateTeamDto {
    @ApiProperty()
    teamId: number
    @ApiProperty()
    name :string
    @ApiProperty()
    projectId: number
    constructor(tId:number,name:string,pId:number){
        this.name=name
        this.projectId=pId
        this.teamId=tId
    }
}
