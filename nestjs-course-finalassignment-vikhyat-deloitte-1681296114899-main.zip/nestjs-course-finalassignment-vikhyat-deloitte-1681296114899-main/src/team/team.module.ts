import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { TeamService } from './team.service';
import { TeamController } from './team.controller';
import { PrismaModule } from 'src/prisma/prisma.module';
import { LoggerMiddleware } from 'src/middleware/logger.middleware.ts';

@Module({
  imports:[PrismaModule],
  controllers: [TeamController],
  providers: [TeamService]
})
export class TeamModule {}