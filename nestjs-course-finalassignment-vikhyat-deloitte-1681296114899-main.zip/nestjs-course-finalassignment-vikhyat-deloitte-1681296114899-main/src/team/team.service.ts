import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateTeamDto } from './dto/create-team.dto';
import { AddUserToTeamDto } from './dto/update-team.dto';
import { PrismaService } from '../prisma/prisma.service';
import { Team } from '@prisma/client';
import { User } from '@prisma/client';
import { AuthGuard } from '@nestjs/passport';
import { AccessTokenGuard } from 'src/auth/access-token-guard';
// import { equals } from 'class-validator';
@Injectable()
export class TeamService {
  constructor(private readonly pService:PrismaService){}
  async create(createTeamDto: CreateTeamDto) : Promise<Team>{
    try{
      let checkProjectId= await this.pService.project.findMany({
        where:{
          projectId:createTeamDto.projectId
        }
      })
      if(!checkProjectId.length) throw new Error('Project ID not found')
      return await this.pService.team.create({data:{...createTeamDto}})
    }
    catch(e){
      throw new HttpException(e.message,HttpStatus.NOT_FOUND)
    }
  }

  async findAllTeams() : Promise<Team[]>{
    try{

      return await this.pService.team.findMany()  
    }
    catch(e){
      return e
    }
  }
  async findTeamById(id: number) : Promise<Team|string>{
    if(!parseInt(''+id)) return 'Enter Valid Number'
    try{
      let result=await this.pService.team.findFirst({
        where:{
          teamId:id
        }
      })
      if(!result) throw new Error('Team ID not found')
      return result
    }
    catch(e){
      if(e.message && e.message=='Team ID not found') throw new HttpException(e.message,HttpStatus.NOT_FOUND)
      throw new HttpException(e,HttpStatus.BAD_REQUEST)
    }
  }

  async update(updateTeamDto: AddUserToTeamDto) {
    var users =updateTeamDto.users
    // for(var user of updateTeamDto.users){
    //   console.log(updateTeamDto.teamId)
    //   await this.pService.team.update({
    //     where: {
    //       teamId: updateTeamDto.teamId,
    //     },
    //     data:{
    //       users:{
    //         push: user
    //     },
    //   },
    // })
    // users=users.map(Number)
    
    // }
  }

  
}
