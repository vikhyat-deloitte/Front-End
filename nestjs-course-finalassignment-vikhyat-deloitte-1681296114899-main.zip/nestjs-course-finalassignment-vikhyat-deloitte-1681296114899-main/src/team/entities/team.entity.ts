import { User } from "@prisma/client"

export class Team {
    teamId: number
    name :string
    projectId: number
    users: User[]
    constructor(tId:number,name:string,pId:number,curUsers:User[]){
        this.name=name
        this.projectId=pId
        this.teamId=tId
        this.users=curUsers
    }

}
