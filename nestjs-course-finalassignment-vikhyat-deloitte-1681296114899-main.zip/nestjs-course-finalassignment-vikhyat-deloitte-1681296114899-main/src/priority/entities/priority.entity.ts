export class Priority {}
