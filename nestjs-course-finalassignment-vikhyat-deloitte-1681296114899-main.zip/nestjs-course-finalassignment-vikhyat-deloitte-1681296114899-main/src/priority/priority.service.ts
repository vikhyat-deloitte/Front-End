import { Injectable } from '@nestjs/common';
import { CreatePriorityDto } from './dto/create-priority.dto';
import { UpdatePriorityDto } from './dto/update-priority.dto';
import { PrismaService } from '../prisma/prisma.service';
import { Priority } from '@prisma/client';
@Injectable()
export class PriorityService {
  constructor(private readonly pService: PrismaService){}

  //retrieve all priorities
  findAll(): Promise<Priority[]> {
    try{
      return this.pService.priority.findMany()
    }
    catch(e){
      return e
    }
  }
}
