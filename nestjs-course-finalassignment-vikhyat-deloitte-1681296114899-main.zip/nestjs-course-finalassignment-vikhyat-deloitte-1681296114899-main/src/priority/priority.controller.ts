import { Controller, Get } from '@nestjs/common';
import { PriorityService } from './priority.service';
import { CreatePriorityDto } from './dto/create-priority.dto';
import { UpdatePriorityDto } from './dto/update-priority.dto';
import { Priority } from '@prisma/client';
@Controller('priority')
export class PriorityController {
  constructor(private readonly priorityService: PriorityService) {}

  //get request to retrieve all the priorities 
  @Get()
  findAllPriorities() :Promise<Priority[]> {
    return this.priorityService.findAll();
  }

}
