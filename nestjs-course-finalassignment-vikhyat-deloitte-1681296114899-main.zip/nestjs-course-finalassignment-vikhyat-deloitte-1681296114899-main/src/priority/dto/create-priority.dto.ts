export class CreatePriorityDto {}
