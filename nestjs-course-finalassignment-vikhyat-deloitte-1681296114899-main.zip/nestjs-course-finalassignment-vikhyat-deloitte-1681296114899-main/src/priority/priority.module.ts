import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { PriorityService } from './priority.service';
import { PriorityController } from './priority.controller';
import { PrismaModule } from 'src/prisma/prisma.module';
import { LoggerMiddleware } from 'src/middleware/logger.middleware.ts';

@Module({
  controllers: [PriorityController],
  providers: [PriorityService],
  imports:[PrismaModule]
})
export class PriorityModule {}